import vosk
import pyaudio
import pyttsx3
import re
import os
import datetime
import calendar
import pickle
import threading
import time
import numpy as np
from word2number_es import w2n
import tkinter as tk
from tkinter.font import Font
import sys
from playsound import playsound  
from PIL import Image, ImageTk  
import glob
import random
from PIL import Image
from PIL import ImageTk
import cv2
import imutils
from capturandoRostros import capturando_rostros

PWM_PIN = 12

def start_capturing():
    capturando_rostros()
    
rostros_thread = threading.Thread(target=start_capturing)
rostros_thread.start()

# Función para que el asistente hable
def speak(text):
    os.system(f'echo "{text}" | festival --tts --language spanish')
    


# Expresiones regulares para coincidencia parcial

# Reloj
pattern_consultar_hora = re.compile(r"\b(hora)\b", re.IGNORECASE)
pattern_configurar_alarma = re.compile(r"\b(alarma)\b", re.IGNORECASE)
pattern_configurar_temporizador = re.compile(r"\b(temporizador|temporizar)\b", re.IGNORECASE)
pattern_configurar_contador = re.compile(r"\b(contar|cuenta|contador)\b", re.IGNORECASE)

# Juegos y terapias
pattern_terapia = re.compile(r"\b(terapia)\b", re.IGNORECASE)
pattern_juegos = re.compile(r"\b(jugar|juego)\b", re.IGNORECASE)
pattern_remember = re.compile(r"\b(recordar)\b", re.IGNORECASE)
pattern_back = re.compile(r"\b(atrás)\b", re.IGNORECASE)
pattern_af = re.compile(r"\b(atención|focal)\b", re.IGNORECASE)
pattern_bv = re.compile(r"\b(busqueda|visual)\b", re.IGNORECASE)
pattern_c = re.compile(r"\b(concentración)\b", re.IGNORECASE)

# Otros
pattern_ayuda = re.compile(r"\b(ayuda|ayúdame|instrucciones)\b", re.IGNORECASE)
pattern_saludo = re.compile(r"\b(hola|buenos días|buenas tardes|buenas noches)\b", re.IGNORECASE)
pattern_despedida = re.compile(r"\b(adiós|hasta luego|chao|nos vemos)\b", re.IGNORECASE)
pattern_detener = re.compile(r"\b(para|basta|detente|termina)\b", re.IGNORECASE)

# Sistema
pattern_cambiar_color = re.compile(r"\b(cambiar|poner|configurar) ?(el|la)? (fondo|pantalla|tema) ?(a)?\b", re.IGNORECASE)


def juego_af():
    label_info.config(text="")
    directorio = 'ejercicios/Atencion_focal'
    ruta_directorio = os.path.join(os.getcwd(), directorio)

    # Obtener todas las imágenes en el directorio que terminan con .png, ordenadas por nombre
    imagenes = sorted([f for f in os.listdir(ruta_directorio) if f.endswith('.png')])
    
    for n, imagen in enumerate(imagenes):
        load_and_show_image(os.path.join(ruta_directorio, imagen))
        speak(f"De las imagenes de la derecha, ¿cual es igual a la numero {n}?")
        acertado = False
        while not acertado:
            query = listen(tiempo_minimo=2, tiempo_maximo=4)
            if n == 0 or n == 1:
                if re.search(r"\b(cuatro|4)\b", query, re.IGNORECASE):
                    speak("¡Muy bien! Has acertado. A por el siguiente.")
                    time.sleep(2)
                    acertado = True
                elif re.search(r"\b(uno|dos|tres|1|2|3)\b", query, re.IGNORECASE):
                    speak("Ups. Me parece que es incorrecto.")
                    time.sleep(3)
                else:
                    speak("Lo siento. No te he entendido.")
                    time.sleep(1)
            elif n == 2:
                if re.search(r"\b(dos|2)\b", query, re.IGNORECASE):
                    speak("¡Muy bien! Has acertado. A por el siguiente.")
                    time.sleep(2)
                    acertado = True
                elif re.search(r"\b(uno|cuatro|tres|1|4|3)\b", query, re.IGNORECASE):
                    speak("Ups. Me parece que es incorrecto.")
                    time.sleep(3)
                else:
                    speak("Lo siento. No te he entendido.")
                    time.sleep(1)
            elif n == 3:
                if re.search(r"\b(tres|3)\b", query, re.IGNORECASE):
                    speak("¡Muy bien! Has acertado.")
                    time.sleep(2)
                    acertado = True
                elif re.search(r"\b(uno|cuatro|dos|1|4|2)\b", query, re.IGNORECASE):
                    speak("Ups. Me parece que es incorrecto.")
                    time.sleep(3)
                else:
                    speak("Lo siento. No te he entendido.")
                    time.sleep(1)

    load_and_show_image(os.path.join('init', "menu.png"))
    
def juego_bv():
    label_info.config(text="")
    directorio = 'ejercicios\Busqueda_visual'
    ruta_directorio = os.path.join(os.getcwd(), directorio)
    # Obtener todas las imágenes en el directorio que terminan con .png, ordenadas por nombre
    imagenes = sorted([f for f in os.listdir(ruta_directorio) if f.endswith('.png')])
    
    for n, imagen in enumerate(imagenes):
        #Habria que poner un tutorial de como funcionan los juegos
        load_and_show_image(os.path.join(ruta_directorio, imagen))
        speak("Encuentra la figura que es igual a la del circulo de entre todas estas")
        acertado = False
        while not acertado:
            query = listen(tiempo_minimo=2, tiempo_maximo=4)
            if n == 0:
                if (re.compile(r"\b(cinco|5)\b", re.IGNORECASE)).search(query):
                    speak("¡Muy bien! Has acertado. A por el siguiente.")
                    time.sleep(2)
                    acertado = True
                    break
                elif (re.compile(r"\b(uno|dos|tres|cuatro|seis|siete|ocho|nueve|diez|once|doce|1|2|3|4|6|7|8|9|10|11|12)\b", re.IGNORECASE)).search(query):
                    speak("Ups. Me parece que es incorrecto.")
                    time.sleep(3)
                else:
                    speak("Lo siento. No te he entendido.")
                    time.sleep(1)
            if n == 1:
                if (re.compile(r"\b(once|11)\b", re.IGNORECASE)).search(query):
                    speak("¡Muy bien! Has acertado. A por el siguiente.")
                    time.sleep(2)
                    acertado = True
                    break
                elif (re.compile(r"\b(uno|dos|tres|cuatro|seis|siete|ocho|nueve|diez|cinco|doce|1|2|3|4|6|7|8|9|10|5|12)\b", re.IGNORECASE)).search(query):
                    speak("Ups. Me parece que es incorrecto.")
                    time.sleep(3)
                else:
                    speak("Lo siento. No te he entendido.")
                    time.sleep(1)
            if n == 2:
                if (re.compile(r"\b(ocho|8)\b", re.IGNORECASE)).search(query):
                    speak("¡Muy bien! Has acertado. A por el siguiente.")
                    time.sleep(2)
                    acertado = True
                    break
                elif (re.compile(r"\b(uno|dos|tres|cuatro|seis|siete|cinco|nueve|diez|once|doce|1|2|3|4|6|7|5|9|10|11|12)\b", re.IGNORECASE)).search(query):
                    speak("Ups. Me parece que es incorrecto.")
                    time.sleep(3)
                else:
                    speak("Lo siento. No te he entendido.")
                    time.sleep(1)
            if n == 3:
                if (re.compile(r"\b(nueve|9)\b", re.IGNORECASE)).search(query):
                    speak("¡Muy bien! Has acertado.")
                    time.sleep(2)
                    acertado = True
                    break
                elif (re.compile(r"\b(uno|dos|tres|cuatro|seis|siete|ocho|cinco|diez|once|doce|1|2|3|4|6|7|8|5|10|11|12)\b", re.IGNORECASE)).search(query):
                    speak("Ups. Me parece que es incorrecto.")
                    time.sleep(3)
                else:
                    speak("Lo siento. No te he entendido.")
                    time.sleep(1)
                    
    
    load_and_show_image(os.path.join('init', "menu.png"))
    

def juego_c():
    directorio = 'ejercicios\Concentracion'
    ruta_directorio = os.path.join(os.getcwd(), directorio)
    patrones = ['ejercicio1_*.png', 'ejercicio2_*.png', 'ejercicio3_*.png']
    ex = []
    respuestas = {
        'ejercicio1_1.png': '6',
        'ejercicio1_2.png': '8',
        'ejercicio1_3.png': '10',
        'ejercicio2_1.png': '4',
        'ejercicio2_2.png': '6',
        'ejercicio2_3.png': '9',
        'ejercicio3_1.png': '7',
        'ejercicio3_2.png': '6',
        'ejercicio3_3.png': '4',
        }
    for patron in patrones:
        imagenes = sorted(glob.glob(os.path.join(ruta_directorio, patron)))
        imagen_seleccionada = random.choice(imagenes)
        ex.append(imagen_seleccionada) #alternativa: ex.extend(imagenes)
    for n, exercices in enumerate(ex):
        load_and_show_image(os.path.join('', exercices))
        speak("¿Cuantas figuras iguales hay?")
        acertado = False
        while not acertado:
            query = listen(tiempo_minimo=2, tiempo_maximo=4)
            if query == respuestas[os.path.basename(exercices)]:
                speak("¡Muy bien! Has acertado. A por el siguiente.")
                time.sleep(2)
                acertado = True
                break
            else:
                speak("Ups. Me parece que es incorrecto.")
                time.sleep(3)
                
    load_and_show_image(os.path.join('init', "menu.png"))


def visualizar():
    global cap
    if cap is not None:
        ret, frame = cap.read()
        if ret == True:
            frame = imutils.resize(frame, width=640)
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            im = Image.fromarray(frame)
            img = ImageTk.PhotoImage(image=im)
            lblVideo.configure(image=img)
            lblVideo.image = img
            lblVideo.after(10, visualizar)
        else:
            lblVideo.image = ""
            cap.release()

def remember():
    video_path = "C:\\Users\\jacot\\Downloads\\speech_recognition-main\\speech_recognition-main\\remembere.mp4"
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        speak("No se pudo abrir la ventana")
    else:
        speak("El video se va a visualizar")
        lblVideo.lift() 
        visualizar()
       

def ayuda():
    load_and_show_image(os.path.join('init', "ayuda.png"))
    label_info.configure(fg='black')
    mensaje = """
    ¡Bienvenido al asistente de voz!
    
    Puedes usar los siguientes comandos:
    
    - Saludos: Puedes saludarme diciendo "Hola", "Buenos días", "Buenas tardes" o "Buenas noches".
    
    - Consultar la hora: Simplemente menciona "hora" y te diré la hora actual.
    
    - Consultar eventos: Di "consultar eventos" para ver los eventos agendados para hoy.
    
    - Agregar evento: Di "agregar evento" para añadir un nuevo evento a tu agenda.
    
    - Modificar evento: Si necesitas hacer cambios de horario a un evento existente, di "modificar evento".
    
    - Eliminar evento: Di "eliminar evento" para borrar un evento de tu agenda.
    
    - Mostrar tareas: Para ver tus tareas pendientes, di "mostrar tareas".
    
    - Agregar tarea: Para añadir una nueva tarea a tu lista, di "agregar tarea".
    
    - Marcar tarea como completada: Si has completado una tarea, di "marcar tarea como completada".
    
    - Eliminar tarea: Si deseas borrar una tarea de tu lista, di "eliminar tarea".
    
    - Agregar nota: Puedes guardar notas de voz diciendo "agregar nota".
    
    - Reproducir nota: Si quieres escuchar tus notas guardadas, di "reproducir nota".
    
    - Eliminar nota: Para eliminar una nota, simplemente di "eliminar nota".
    
    - Configurar alarma: Si necesitas una alarma, di "alarma".
    
    - Configurar temporizador: Para establecer un temporizador, di "temporizador".
    
    - Configurar contador: Para establecer un contador, di "cuenta"
    
    - Juegos: ¡También puedo entretenerte con algunos juegos!
    
    - Ayuda: Siempre puedes pedir ayuda diciendo "ayuda" o "ayúdame por favor".
    
    ¡Espero que encuentres útiles estas opciones!
    """
    print(mensaje)
    label_info.config(text=mensaje)
    ajustar_tamaño_texto()
    speak(mensaje)

# Función para escuchar al usuario y manejar errores de escucha

# Define la ruta al modelo de reconocimiento de voz
model_path = "./vosk-model-small-es-0.42"

# Carga el modelo de reconocimiento de voz
model = vosk.Model(model_path)

# Configura la configuración de PyAudio
FORMAT = pyaudio.paInt16
CHANNELS = 1
RATE = 16000
CHUNK = 1024

# Inicia PyAudio
audio = pyaudio.PyAudio()

# Abre el stream de audio desde el micrófono
stream = audio.open(format=FORMAT, channels=CHANNELS,
                    rate=RATE, input=True,
                    frames_per_buffer=CHUNK)

# Crea un reconocedor de voz utilizando el modelo especificado
recognizer = vosk.KaldiRecognizer(model, RATE)

def listen(tiempo_minimo=2, tiempo_maximo=4):
    global activacion
    
    try:
        eliminar = False
        if activacion:
            # Dibujar la franja azul que ocupe todo el ancho
            franja = canvas.create_rectangle(0, 0, root.winfo_screenwidth(), 30, outline="")
            canvas.itemconfig(franja, fill="cyan")
            eliminar = True
        
        print("Escuchando...")
        start_time_maximo = time.time()
        start_time_minimo = time.time()  # Almacena el tiempo sin escuchar nada
        audio_buffer = []  # Almacena el audio durante el tiempo de escucha
        
        while time.time() - start_time_maximo < tiempo_maximo:
            #print(time.time() - start_time_maximo, "<", tiempo_maximo)
            data = stream.read(CHUNK)
            
            if recognizer.AcceptWaveform(data):
                audio_buffer.append(data)  # Agrega el audio al buffer
        
            audio_array = np.frombuffer(data, dtype=np.int16)
            energia_promedio = np.mean(np.abs(audio_array))
        
            if energia_promedio > 750:
                start_time_minimo = time.time()
                #print("Tiempo mínimo reiniciado")
            else:
                #print(time.time() - start_time_minimo, ">=", tiempo_minimo)
                if time.time() - start_time_minimo >= tiempo_minimo:
                    #print("Tiempo mínimo sin hablar superado")
                    break
                
        if eliminar:
            canvas.delete(franja)  # Eliminar la franja azul del lienzo
            
        # Procesa el audio acumulado para obtener el texto escuchado
        recognizer.AcceptWaveform(b''.join(audio_buffer))
        result = recognizer.Result()
        query = eval(result)["text"]
        if query is not None:
            query = convertir_numeros(query).lower()
            print(f"¿Has dicho: {query}?")
            return query
            
        return ""
    except Exception as e:  # Maneja cualquier excepción
        print("Error:", e)
        return ""

def convertir_numeros(texto):
    palabras = texto.split()  # Divide el texto en palabras
    
    # Primer bucle: convierte palabras a números si es posible
    i = 0
    while i < len(palabras):
        try:
            palabra = palabras[i] # Toma la palabra actual
            if not palabra.isdigit(): # Verifica si la palabra no es un número
            
                if palabra == "un":
                    palabra = "uno"
                    
                numero = w2n.word_to_num(palabra) # Convierte la palabra a número
            else:
                numero = int(palabra) # Si ya es un número, conviértelo a entero
            #print(type(numero))
            
            if numero == 1000000000: # Si es mil millones, conviértelo a un millón
                numero = 1000000
                
            if isinstance(numero, int): # Si es un entero, reemplaza la palabra por el número
                palabras[i] = str(numero)
                #print(palabra, "=", numero)
        except ValueError: 
            # Maneja errores de conversión
            pass
        
        i += 1
    
    # Segundo bucle: procesa la suma y la multiplicación
    i = 1
    while i < len(palabras):
        
        # Si hay una palabra "y" entre dos números
        if i + 2 < len(palabras) and palabras[i + 1] == "y":
            try:
                numero_1 = palabras[i + 0]
                if numero_1.isdigit():
                    numero_1 = int(numero_1)
                #print(type(numero_1))
                
                numero_2 = palabras[i + 2]
                if numero_2.isdigit():
                    numero_2 = int(numero_2)
                #print(type(numero_2))
                
                # Si ambos son enteros, realiza la suma
                if isinstance(numero_1, int) and isinstance(numero_2, int):
                    palabras[i + 0:i + 3] = [str(numero_1 + numero_2)]
                    #print(numero_1, "+y", numero_2, "=", palabras[i])
            except (ValueError, IndexError):
                pass
            
        try:
            numero_1 = palabras[i - 1]
            if numero_1.isdigit():
                numero_1 = int(numero_1)
            #print(type(numero_1))
            
            numero_2 = palabras[i + 0]
            if numero_2.isdigit():
                numero_2 = int(numero_2)
            #print(type(numero_2))

            # Si ambos son enteros, procesa la operación
            if isinstance(numero_1, int) and isinstance(numero_2, int):
                if numero_2 == 1000 or numero_2 == 1000000:
                    palabras[i - 1:i + 1] = [str(numero_1 * numero_2)]
                    #print(numero_1, "*", numero_2, "=", palabras[i - 1])
                    continue
                else:
                    if numero_1 == 100:
                        palabras[i - 1:i + 1] = [str(numero_1 + numero_2)]
                        #print(numero_1, "+", numero_2, "=", palabras[i - 1])
                        continue
                    
                    if i + 1 < len(palabras):
                        numero_3 = palabras[i + 1]
                        if numero_3.isdigit():
                            numero_3 = int(numero_3)
                        #print(type(numero_3))
    
                        if isinstance(numero_2, int) and isinstance(numero_3, int):
                            if numero_3 == 1000:
                                palabras[i + 0:i + 2] = [str(numero_2 * numero_3)]
                                #print(numero_2, "*", numero_3, "=", palabras[i + 0])
                                continue
                    
                    palabras[i - 1:i + 1] = [str(numero_1 + numero_2)]
                    #print(numero_1, "+", numero_2, "=", palabras[i - 1])
                    continue
        except (ValueError, IndexError):
            pass
        
        i += 1
    return ' '.join(palabras) # Une las palabras en un texto nuevamente

pattern_activacion = re.compile(r"\b(paco|opaco|pago|bajo|macho|banco)\b", re.IGNORECASE)

def main_loop():
    
    global alarma_activada
    alarma_activada = False
    
    global activacion
    activacion = False
    
    global detener
    detener = False
    
    global terapia
    terapia = False
    
    global ayuda_var
    ayuda_var = False
    
    def cambiar_imagen_fondo():
        if not terapia and not ayuda_var:
            imagenes = [f for f in os.listdir('init/asistente') if f.endswith(('png', 'jpg', 'jpeg'))]
            imagen_aleatoria = random.choice(imagenes)
            load_and_show_image(os.path.join('init/asistente', imagen_aleatoria))
            root.after(5000, cambiar_imagen_fondo)  # Llama de nuevo a la función después de 5 segundos
    
    # Carga la imagen inicial
    load_and_show_image(os.path.join('init', "black_logo.png"))
    time.sleep(2)
    load_and_show_image(os.path.join('init', "asistente.png"))
    label_info.config(text="Lopako")
    ajustar_tamaño_texto()
    
    root.after(5000, cambiar_imagen_fondo)
    while not detener:
        if not alarma_activada:
            query = listen(tiempo_minimo=2, tiempo_maximo=4)
        
            if query and activacion:
                    
                # Juegos y terapia
                if pattern_terapia.search(query):
                    load_and_show_image(os.path.join('init', "menu.png"))
                    terapia = True
                    
                elif pattern_juegos.search(query):
                    load_and_show_image(os.path.join('ejercicios', "menu_juegos.png"))
                    
                elif pattern_back.search(query):
                    load_and_show_image(os.path.join('init', "menu.png"))
                    
                elif pattern_remember.search(query):
                    remember()
                    
                elif pattern_af.search(query):
                    juego_af()
                    
                elif pattern_bv.search(query):
                    juego_bv()
                    
                elif pattern_c.search(query):
                    juego_c()
    
                # Despedida
                elif pattern_despedida.search(query):
                    label_info.config(text="¡Hasta luego! Que tengas un buen día.")
                    ajustar_tamaño_texto()
                    speak("¡Hasta luego! Que tengas un buen día.")
    
                # Ayuda
                elif pattern_ayuda.search(query):
                    ayuda_var = True
                    ayuda()
                    ayuda_var = False
                    load_and_show_image(os.path.join('init', "asistente.png"))
                    label_info.config(text="¿En qué puedo ayudarte?")
                    ajustar_tamaño_texto()
                    label_info.configure(fg='white')
                    speak("¿En qué puedo ayudarte?")
                    continue
                    
                # Procesamiento de consultas generales
                elif pattern_saludo.search(query):
                    label_info.config(text="¡Hola! ¿En que puedo ayudarte?")
                    ajustar_tamaño_texto()
                    speak("¡Hola! ¿En que puedo ayudarte?")
                    continue
                
                # Configuracion del sistema
                elif pattern_cambiar_color.search(query):
                    cambiar_color(query)
                
                else:
                    label_info.config(text="Lo siento, no entendi eso. ¿Puedes repetir?")
                    ajustar_tamaño_texto()
                    speak("Lo siento, no entendi eso. ¿Puedes repetir?")
                    continue
                
                activacion = False
                if(terapia == False): 
                    label_info.config(text="Lopako") 
                else: label_info.config(text="")
                ajustar_tamaño_texto()
            elif pattern_activacion.search(query):
                if(terapia == False): 
                    label_info.config(text="En que puedo ayudarte?")
                else: label_info.config(text="")
                ajustar_tamaño_texto()
                speak("¿En que puedo ayudarte?")
                activacion = True
        else:
            speak("¡Alarma!")
            time.sleep(0.5)
            speak("¡Alarma!")
            time.sleep(0.5)
            speak("¡Alarma!")
            time.sleep(0.5)
            # Aquí podría agregar la reproducción de un sonido de alarma o cualquier otra acción que desee.
            parar = listen(tiempo_minimo=2, tiempo_maximo=2)
            if pattern_detener.search(parar):
                label_info.config(text="Alarma detenida.")
                ajustar_tamaño_texto()
                speak("Alarma detenida.")
                alarma_activada = False
                activacion = False
                label_info.config(text="Lopako")
                ajustar_tamaño_texto()

def detener_programa():
    global detener
    detener = True
    
    root.quit()  # Detener el bucle principal de Tkinter
    root.destroy()  # Cierra la ventana principal
    if main_thread and main_thread.is_alive():
        main_thread.join()  # Espera a que el hilo principal termine antes de salir
    sys.exit()  # Sale del programa por completo

def ajustar_tamaño_texto(event=None):
    texto = label_info["text"]
    lineas = texto.split("\n")
    longitud_maxima = max(len(linea) for linea in lineas)
    altura_maxima = len(lineas)
    
    # Buscamos el tamaño de fuente más cercano para la longitud máxima de la línea
    tamaño_fuente_ancho = None
    for tamaño, longitud in sorted(letras_por_linea.items(), reverse=True):
        if longitud >= longitud_maxima:
            tamaño_fuente_ancho = tamaño
            break
    if tamaño_fuente_ancho is None:
        tamaño_fuente_ancho = 10  # Si no se encontró ninguna coincidencia, asignamos un valor por defecto
    
    # Buscamos el tamaño de fuente más cercano para la altura máxima de texto
    tamaño_fuente_alto = None
    for tamaño, altura in sorted(lineas_por_pantalla.items(), reverse=True):
        if altura >= altura_maxima:
            tamaño_fuente_alto = tamaño
            break
    if tamaño_fuente_alto is None:
        tamaño_fuente_alto = 10  # Si no se encontró ninguna coincidencia, asignamos un valor por defecto
    
    # Obtenemos el tamaño de fuente más pequeño para asegurarnos de que quepa tanto por ancho como por alto
    tamaño_fuente = min(tamaño_fuente_ancho, tamaño_fuente_alto)
    
    # Reducir el tamaño del texto
    tamaño_fuente = max(tamaño_fuente // 2, 10)
    
    label_info.config(font=("Arial", tamaño_fuente))
    label_info.update()
    
def calcular_letras_por_linea(ventana):
    tamaño_fuente_por_linea = {}
    for tamaño_fuente in range(10, 101):  # Tamaños de fuente de 10 a 50
        font = Font(size=tamaño_fuente)
        ancho_caracter = font.measure("W")  # Anchura de un carácter genérico
        ancho_ventana = ventana.winfo_screenwidth() * 2
        tamaño_fuente_por_linea[tamaño_fuente] = int(ancho_ventana // ancho_caracter)
    return tamaño_fuente_por_linea

def calcular_lineas_por_pantalla(ventana):
    lineas_por_pantalla = {}
    for tamaño_fuente in range(10, 101):  # Tamaños de fuente de 10 a 50
        font = Font(size=tamaño_fuente)
        altura_linea = font.metrics("linespace") * 2
        altura_pantalla = ventana.winfo_screenheight()
        lineas_por_pantalla[tamaño_fuente] = int(altura_pantalla // altura_linea)
    return lineas_por_pantalla
    
def cambiar_color(query):
    color_fondo, color_texto = parsear_color(query)
    while not color_fondo and not color_texto:
        label_info.config(text="Por favor, escoge entre los colores blanco, gris y negro.")
        ajustar_tamaño_texto()
        speak("Por favor, escoge entre los colores blanco, gris y negro.")
        
        color_str = listen()
        if pattern_detener.search(color_str):
            return
        color_fondo, color_texto = parsear_color(color_str)
        if not color_fondo and not color_texto:
            label_info.config(text="No se pudo entender el color. Por favor, intenta de nuevo.")
            ajustar_tamaño_texto()
            speak("No se pudo entender el color. Por favor, intenta de nuevo.")
    
    root.configure(bg=color_fondo)
    
    label_info.configure(bg=color_fondo)
    label_info.configure(fg=color_texto)
    return

def parsear_color(color):
    # Expresión regular para extraer el color
    patron_color = re.compile(r"\b(blanco|claro|gris|opaco|negro|oscuro)\b", re.IGNORECASE)
    match = patron_color.search(color)
    if match:
        # Comprobar los grupos de coincidencia para obtener el color correcto
        for grupo in match.groups():
            if grupo:
                if re.search(r"\b(blanco|claro)\b", grupo, re.IGNORECASE):
                    return "white", "black"
                elif re.search(r"\b(gris|opaco)\b", grupo, re.IGNORECASE):
                    return "gray", "white"
                elif re.search(r"\b(negro|oscuro)\b", grupo, re.IGNORECASE):
                    return "black", "white"          
    return None, None

# Esta función carga y muestra una imagen en un widget Label de Tkinter
def load_and_show_image(image_path):
    if image_path:
        # Obtener las dimensiones de la pantalla
        screen_width = label_info.winfo_screenwidth()
        screen_height = label_info.winfo_screenheight()
    
        # Cargar la imagen y redimensionarla para que ocupe toda la pantalla
        image = Image.open(image_path)
        image = image.resize((screen_width, screen_height))
        
        # Convertir la imagen para mostrarla en Tkinter
        photo = ImageTk.PhotoImage(image)
    
        # Configurar la imagen en el widget Label
        label_info.configure(image=photo)
        label_info.image = photo  # Mantén una referencia global a la imagen
        label_info.update()
    else:
        # Configurar la imagen en el widget Label
        label_info.configure(image="")
        label_info.update()

# Esta función carga y reproduce el audio correspondiente a la dirección dada
def load_and_play_audio(audio_path):
    playsound(audio_path)

# Crear la ventana principal
root = tk.Tk()
root.title("Lopako")

# Ajustar tamaño de la ventana para que ocupe toda la pantalla
root.attributes('-fullscreen', True)

# Crear el widget Label con texto
label_info = tk.Label(root, text="", justify="center", compound="center")
label_info.pack(expand=True, fill='both')
label_info.configure(fg="white")

letras_por_linea = calcular_letras_por_linea(label_info)
lineas_por_pantalla = calcular_lineas_por_pantalla(label_info)

# Crear un lienzo (canvas) y hacer que ocupe todo el ancho
canvas = tk.Canvas(root, height=30)
canvas.pack(side="bottom", fill="x")

# Botón para detener el programa
btn_detener = tk.Button(root, text="Detener programa", command=detener_programa)
btn_detener.pack(side=tk.TOP, anchor=tk.NE)  # Coloca el botón en la esquina superior derecha

#comenzar el bucle principal en un hilo aparte
main_thread = threading.Thread(target=main_loop)
main_thread.start()

cap = None
lblVideo = tk.Label(root)
lblVideo.pack(expand=True, fill='both')

# Ejecutar la aplicación
root.mainloop()

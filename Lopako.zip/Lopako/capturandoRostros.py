import cv2
import os
import imutils
import numpy as np

def capturando_rostros():
    ## CAPTURANDO ROSTROS ##
    personName = 'Javi' #Modificar para cuando detecte un individuo
    currentPath = os.getcwd()  # Obtiene la ruta del directorio actual
    dataPath = os.path.join(currentPath, 'Data')  # Construye la ruta a la carpeta 'Data' en el directorio actual
    personPath = os.path.join(dataPath, personName)
    
    if not os.path.exists(personPath):
        print('Carpeta creada: ', personPath)
        os.makedirs(personPath)
    
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    
    faceClassif = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    count = 0
    
    while True:
        ret, frame = cap.read()
        if not ret: 
            break
    
        frame = imutils.resize(frame, width=640)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        auxFrame = frame.copy()
    
        faces = faceClassif.detectMultiScale(gray, 1.3, 5)
    
        for (x, y, w, h) in faces:
            rostro = auxFrame[y:y+h, x:x+w]
            rostro = cv2.resize(rostro, (150, 150), interpolation=cv2.INTER_CUBIC)
            cv2.imwrite(os.path.join(personPath, 'rostro_{}.jpg'.format(count)), rostro)
            count += 1
    
        # Si se han capturado 300 imágenes, termina el bucle
        if count >= 200:
            break
    
    cap.release()
    cv2.destroyAllWindows()
    
    ## ENTRENANDO ##
    currentPath = os.getcwd()
    dataPath = os.path.join(currentPath, 'Data')  # Construye la ruta a la carpeta 'Data' en el directorio actual
    peopleList = os.listdir(dataPath)
    print('Lista de personas: ', peopleList)
    
    labels = []
    facesData = []
    label = 0
    
    for nameDir in peopleList:
    	personPath = dataPath + '/' + nameDir
    
    	for fileName in os.listdir(personPath):
    		labels.append(label)
    		facesData.append(cv2.imread(personPath+'/'+fileName,0))
    	label = label + 1
    
    # Métodos para entrenar el reconocedor
    face_recognizer = cv2.face.EigenFaceRecognizer_create()
    
    # Entrenando el reconocedor de rostros
    print("Entrenando...")
    face_recognizer.train(facesData, np.array(labels))
    
    # Almacenando el modelo obtenido
    face_recognizer.write('modeloEigenFace.xml')
    print("Modelo almacenado...")
